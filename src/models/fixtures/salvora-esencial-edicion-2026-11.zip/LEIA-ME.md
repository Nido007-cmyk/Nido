# SALVORA PACKS · Essencial, edição 2026-11

## O que é isto

A edição empacotada pela SALVORA PACKS do pacote Essencial: 174 guias práticos que funcionam sem conexão, escritos a partir de fontes oficiais e verificados um a um.

- Primeiros socorros: 25 guias por idioma
- Desastres: 15 guias por idioma
- Sobrevivência: 11 guias por idioma
- Saúde em casa: 7 guias por idioma
- Idiomas: português, espanhol e inglês (58 guias em cada um)

Fontes dos guias, citadas dentro de cada um: diretrizes de RCP e primeiros socorros da AHA e da Cruz Vermelha (2024 e 2025), IFRC, OMS, UNICEF, CDC, FEMA e Ready.gov, NOAA, USGS e outras autoridades públicas de cada tema. Os 174 guias levam a sua data de verificação dentro de cada um; a edição completa (knowledge-packs-v16) foi reverificada em 2026-11-08 contra as edições vigentes das suas fontes (IFRC 2025, ERC 2025).

A edição multilíngue (o arquivo e5) foi testada ao construir esta edição: 202 de 202 perguntas de teste encontram o seu guia entre os primeiros resultados.

## O que contém este download

- `nido-esencial.sqlite`: o pacote, edição padrão
- `nido-esencial-e5.sqlite`: o mesmo pacote com busca multilíngue melhorada
- Os dois arquivos `.json`: o manifesto de cada arquivo, com a sua impressão digital
- `LICENSE-nido-esencial.txt`: a licença dos textos (CC BY 4.0)
- `VERIFICACION.txt`: as impressões digitais SHA-256 para comprovar que a sua cópia está íntegra

As duas edições trazem o mesmo conteúdo: o que muda é o motor de busca que levam dentro, o padrão e o multilíngue melhorado. Vêm as duas porque o formato aberto do NIDO as define assim.

## Como se usa

No app NIDO para Android (grátis), este mesmo pacote faz parte do seu catálogo e baixa-se dentro do app em Ajustes, Base de conhecimento; o app confere a sua impressão digital antes de o abrir. Desde a versão 0.1.80, o app também adiciona pacotes a partir de um arquivo, nessa mesma tela, com «Adicionar um pacote a partir de um arquivo», conferindo antes de copiar qualquer coisa se a assinatura é do NIDO ou da SALVORA PACKS e se a impressão digital coincide com o manifesto assinado: é assim que entram no app os pacotes desta loja que não estão no seu catálogo, como os da SALVORA PACKS. Este download da loja traz esses mesmos arquivos assinados, para os guardar em seu poder e levar para outro dispositivo. E para ler os guias em qualquer dispositivo e sem nenhum app, esta mesma loja oferece a edição legível deste pacote: os 174 guias em PDF e em texto, nos três idiomas.

## Honestidade da casa

Este mesmo pacote está grátis no repositório público do NIDO no GitHub. Aqui você o baixa empacotado, com as suas instruções e a sua verificação, e apoia o crescimento da biblioteca. Nada do que hoje é grátis deixa de ser.

## Aviso importante

Informação geral apenas. Não substitui um curso de primeiros socorros nem a ajuda profissional. Numa emergência, ligue para o número de emergência da sua localidade.

Textos sob licença CC BY 4.0: compartilhe e adapte citando o NIDO e ligando a licença. As organizações citadas não escreveram nem revisaram estes guias e não apoiam o NIDO nem a SALVORA PACKS.

## Reembolsos

As vendas são finais. Se um arquivo estiver danificado ou não funcionar, ele é reparado ou trocado por uma cópia que funcione, com verificação objetiva pelas impressões digitais publicadas. A compra duplicada por engano é reembolsada. Os direitos que a lei lhe dá como comprador permanecem intactos.
