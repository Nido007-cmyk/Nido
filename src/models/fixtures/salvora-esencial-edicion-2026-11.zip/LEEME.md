# SALVORA PACKS · Esencial, edición 2026-11

## Qué es esto

La edición empaquetada por SALVORA PACKS del paquete Esencial: 174 guías prácticas que funcionan sin conexión, escritas desde fuentes oficiales y verificadas una a una.

- Primeros auxilios: 25 guías por idioma
- Desastres: 15 guías por idioma
- Supervivencia: 11 guías por idioma
- Salud en casa: 7 guías por idioma
- Idiomas: español, inglés y portugués (58 guías en cada uno)

Fuentes de las guías, citadas dentro de cada una: guías de RCP y primeros auxilios de la AHA y la Cruz Roja (2024 y 2025), IFRC, OMS, UNICEF, CDC, FEMA y Ready.gov, NOAA, USGS y otras autoridades públicas del tema. Las 174 guías llevan su fecha de verificación dentro de cada una; la edición completa (knowledge-packs-v16) se re-verificó el 2026-11-08 contra las ediciones vigentes de sus fuentes (IFRC 2025, ERC 2025).

La edición multilingüe (archivo e5) se probó al construir esta edición: 202 de 202 preguntas de prueba encuentran su guía entre los primeros resultados.

## Qué contiene esta descarga

- `nido-esencial.sqlite`: el paquete, edición estándar
- `nido-esencial-e5.sqlite`: el mismo paquete con búsqueda multilingüe mejorada
- Los dos archivos `.json`: el manifiesto de cada archivo, con su huella
- `LICENSE-nido-esencial.txt`: la licencia de los textos (CC BY 4.0)
- `VERIFICACION.txt`: las huellas SHA-256 para comprobar que tu copia es íntegra

Las dos ediciones traen el mismo contenido: lo que cambia es el motor de búsqueda que llevan dentro, el estándar y el multilingüe mejorado. Vienen las dos porque el formato abierto de NIDO las define así.

## Cómo se usa

En la app NIDO para Android (gratis), este mismo paquete forma parte de su catálogo y se descarga dentro de la app desde Ajustes, Base de conocimiento; la app comprueba su huella antes de abrirlo. Desde la versión 0.1.80, la app también añade packs desde un archivo, en esa misma pantalla, con «Añadir un pack desde un archivo», comprobando antes de copiar nada que la firma sea de NIDO o de SALVORA PACKS y que la huella coincida con el manifiesto firmado: así entran en la app los packs de esta tienda que no están en su catálogo, como los de SALVORA PACKS. Esta descarga de la tienda trae esos mismos archivos firmados, para guardarlos en tu poder y llevarlos a otro dispositivo. Y para leer las guías en cualquier dispositivo y sin ninguna app, esta misma tienda ofrece la edición legible de este pack: las 174 guías en PDF y en texto, en los tres idiomas.

## Honestidad de la casa

Este mismo paquete está gratis en el repositorio público de NIDO en GitHub. Aquí lo descargas empaquetado, con sus instrucciones y su verificación, y apoyas que la biblioteca siga creciendo. Nada de lo que hoy es gratis deja de serlo.

## Aviso importante

Información general solamente. No sustituye un curso de primeros auxilios ni la ayuda profesional. En una emergencia, llama al número de emergencias de tu localidad.

Textos bajo licencia CC BY 4.0: compártelos y adáptalos citando a NIDO y enlazando la licencia. Las organizaciones citadas no escribieron ni revisaron estas guías y no respaldan a NIDO ni a SALVORA PACKS.

## Reembolsos

Las ventas son finales. Si un archivo está dañado o no funciona, se repara o se cambia por una copia que funcione, con comprobación objetiva por las huellas publicadas. La compra duplicada por accidente se reembolsa. Los derechos que la ley te da como comprador quedan intactos.
