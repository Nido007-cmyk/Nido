# SALVORA PACKS · Essentials, 2026-11 edition

## What this is

The SALVORA PACKS packaged edition of the Essentials pack: 174 practical guides that work fully offline, written from official sources and verified one by one.

- First aid: 25 guides per language
- Disasters: 15 guides per language
- Survival: 11 guides per language
- Health at home: 7 guides per language
- Languages: English, Spanish and Portuguese (58 guides in each)

Sources, cited inside every guide: AHA and Red Cross CPR and first aid guidelines (2024 and 2025), IFRC, WHO, UNICEF, CDC, FEMA and Ready.gov, NOAA, USGS and other public authorities on each topic. All 174 guides carry their verification date inside each guide; the complete edition (knowledge-packs-v16) was re-verified on 2026-11-08 against the current editions of its sources (IFRC 2025, ERC 2025).

The multilingual edition (the e5 file) was tested when this edition was built: 202 of 202 test questions find their guide among the top results.

## What is in this download

- `nido-esencial.sqlite`: the pack, standard edition
- `nido-esencial-e5.sqlite`: the same pack with improved multilingual search
- The two `.json` files: the manifest of each file, with its fingerprint
- `LICENSE-nido-esencial.txt`: the license of the texts (CC BY 4.0)
- `VERIFICACION.txt`: the SHA-256 fingerprints to check your copy is intact

Both editions carry the same content: what changes is the search engine inside, the standard one and the improved multilingual one. Both are included because NIDO's open format defines them that way.

## How to use it

In the NIDO app for Android (free), this same pack is part of its catalog and downloads inside the app from Settings, Knowledge base; the app checks its fingerprint before opening it. Since version 0.1.80, the app also adds packs from a file, on that same screen, with "Add a pack from a file", checking before copying anything that the signature is NIDO's or SALVORA PACKS' and that the fingerprint matches the signed manifest: that is how the packs from this store that are not in its catalog, such as the SALVORA PACKS ones, enter the app. This store download carries those same signed files, to keep in your own hands and carry to another device. And to read the guides on any device with no app at all, this same store offers the reading edition of this pack: all 174 guides in PDF and text, in all three languages.

## House honesty

This same pack is free in NIDO's public GitHub repository. Here you download it packaged, with its instructions and its verification, and you support the library as it grows. Nothing that is free today stops being free.

## Important notice

General information only. Not a substitute for a first aid course or for professional help. In an emergency, call your local emergency number.

Texts under CC BY 4.0 license: share and adapt them crediting NIDO and linking the license. The cited organizations did not write or review these guides and do not endorse NIDO or SALVORA PACKS.

## Refunds

Sales are final. If a file is damaged or does not work, it is repaired or replaced with a copy that works, checked objectively against the published hashes. An accidental duplicate purchase is refunded. The rights the law gives you as a buyer stay intact.
